from requests import request
from rest_framework.response import Response
from rest_framework.views import APIView
from sqlalchemy import null
from .models import Items,Products,Sells,Sizes  
from api.ecommerce.models import ProductStocks,OrderDetails
from datetime import datetime, timedelta



class ProductsView(APIView):
    
    def get(self,request):
        three_days = datetime.now() - timedelta(hours=72)
        try:
            stocks = ProductStocks.objects.all().using('ecommerce');                                # fetching stock from ecommerce
            for stk in stocks:
                pid = stk.product_id
                input_size = stk.variant
                try:
                    sell_count = 0
                    product_quantity = 0
                    largest_price = 0
                    item = Items.objects.get(pid=pid)                                               # fetching items from management
                    size = Sizes.objects.get(size_name__iexact=input_size)                          # fetching size from management
                    product = Products.objects.filter(item_id=item.itemid,size_id=size.size_id);    # fetching product from management
                    
                    for p in product:
                        try:
                            order_details = OrderDetails.objects.filter(product_id=pid,created_at__gt=three_days).using('ecommerce').count();
                            print('order details is',order_details)
                            if order_details > 0:
                                continue
                        except Exception as e:
                            continue
                        if p.product_price > largest_price:
                            largest_price = p.product_price
                        try:
                            sales = Sells.objects.filter(product_id=p.product_id)
                            for s in sales:
                                sell_count += s.sell_quantity
                            product_quantity += p.product_quantity
                        except Exception as e:
                            continue

                    quantity = product_quantity - sell_count

                    try:
                        resp = ProductStocks.objects.using('ecommerce').get(pk=stk.id)
                        resp.qty=product_quantity
                        resp.price=largest_price
                        if largest_price > 0 :
                            resp.save()
                    except Exception as e:
                        continue
                except Exception as e:
                    continue

            return Response({
                'success':True,
                'message':'Batch Executed Successfully'
            })
        except Exception as e:
            print('try 1',e)
            return Response({
                'success':True,
                'message':'Batch Execution Failed',
                'error':e
            })
